/**
 * API Service for connecting the Event Registration System frontend to the Express backend.
 */

const API_BASE = '/api';

// Helper to get headers with JWT token
function getHeaders(contentType: boolean = true): HeadersInit {
  const headers: Record<string, string> = {};
  if (contentType) {
    headers['Content-Type'] = 'application/json';
  }
  const token = localStorage.getItem('event_app_token');
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

// Global response handler
async function handleResponse(response: Response) {
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || 'Something went wrong with the request.');
  }
  return data;
}

export const api = {
  // Authentication
  auth: {
    login: async (credentials: any) => {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(credentials)
      });
      return handleResponse(res);
    },
    signup: async (userData: any) => {
      const res = await fetch(`${API_BASE}/auth/signup`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(userData)
      });
      return handleResponse(res);
    },
    updateProfile: async (profileData: any) => {
      const res = await fetch(`${API_BASE}/profile`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(profileData)
      });
      return handleResponse(res);
    }
  },

  // Events
  events: {
    getAll: async () => {
      const res = await fetch(`${API_BASE}/events`, {
        method: 'GET',
        headers: getHeaders()
      });
      return handleResponse(res);
    },
    getById: async (id: string) => {
      const res = await fetch(`${API_BASE}/events/${id}`, {
        method: 'GET',
        headers: getHeaders()
      });
      return handleResponse(res);
    },
    create: async (eventData: any) => {
      const res = await fetch(`${API_BASE}/events`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(eventData)
      });
      return handleResponse(res);
    },
    update: async (id: string, eventData: any) => {
      const res = await fetch(`${API_BASE}/events/${id}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(eventData)
      });
      return handleResponse(res);
    },
    delete: async (id: string) => {
      const res = await fetch(`${API_BASE}/events/${id}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      return handleResponse(res);
    }
  },

  // Registrations
  registrations: {
    register: async (registrationData: any) => {
      const res = await fetch(`${API_BASE}/register`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(registrationData)
      });
      return handleResponse(res);
    },
    getMyRegistrations: async () => {
      const res = await fetch(`${API_BASE}/myregistrations`, {
        method: 'GET',
        headers: getHeaders()
      });
      return handleResponse(res);
    },
    cancel: async (id: string) => {
      const res = await fetch(`${API_BASE}/register/${id}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      return handleResponse(res);
    }
  },

  // Admin Specific
  admin: {
    getUsers: async () => {
      const res = await fetch(`${API_BASE}/admin/users`, {
        method: 'GET',
        headers: getHeaders()
      });
      return handleResponse(res);
    },
    getRegistrations: async () => {
      const res = await fetch(`${API_BASE}/admin/registrations`, {
        method: 'GET',
        headers: getHeaders()
      });
      return handleResponse(res);
    },
    getStats: async () => {
      const res = await fetch(`${API_BASE}/admin/stats`, {
        method: 'GET',
        headers: getHeaders()
      });
      return handleResponse(res);
    }
  }
};
